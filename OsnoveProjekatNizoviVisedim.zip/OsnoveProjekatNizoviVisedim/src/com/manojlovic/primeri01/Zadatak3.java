/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author manojlovic Napisati program koji od korisnika zahteva da unese broj
 * redova i broj kolona. Napraviti matricu nxm sa random elementima koristeći
 * dvodimenzionalni niz. Napraviti novi dvodimenzionalni niz sa elementima koji
 * su kvadrati elemenata prvog niza.
 */
public class Zadatak3 {

    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static int[][] a;
    private static Random rnd = new Random();

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        //popunjavanje elemenata matrice Random vrednostima
        a = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = rnd.nextInt(20);
            }
        }
        //ispis matrice
        System.out.println("a = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
        
        //dupliranje elemenata matrice a i generisanje nove matrice b.
        int[][] b = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                b[i][j] = a[i][j]*2;
            }
        }
        System.out.println("b = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(b[i][j] + " ");
            }
            System.out.println();
        }

    }
}
