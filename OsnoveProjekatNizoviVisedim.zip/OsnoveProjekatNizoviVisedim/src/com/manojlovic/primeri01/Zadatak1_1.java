/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Scanner;

/**
 *
 * @author manojlovic Učitajte broj vrsta i kolona n i m; Učitajte članove
 * matrice; Prođite petljama kroz matricu i ispišite na konzoli sve parne
 * članove matrice.
 */
public class Zadatak1_1 {

    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static int[][] a;

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        a = new int[n][m];
        //unos elemenata u matricu
        System.out.println("Unesite elemente matrice:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = sc.nextInt();
            }
        }
        //ispis parnih elemenata matrice
        System.out.println("a = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i][j] % 2 == 0) {
                    System.out.print(a[i][j] + " ");
                }
            }
        }
        System.out.println();
    }
}
