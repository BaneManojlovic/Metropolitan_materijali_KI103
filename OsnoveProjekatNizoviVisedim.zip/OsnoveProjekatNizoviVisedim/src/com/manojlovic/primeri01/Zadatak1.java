/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Scanner;

/**
 *
 * @author manojlovic
 */
public class Zadatak1 {

    public static Scanner sc = new Scanner(System.in);
    public static int n, m;
    public static int[][] a;

    //sabira sve elemente u matrici
    public static double zbirElem(int[][] a) {
        double zbir = 0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                zbir = zbir + a[i][j];
            }
        }
        return zbir;
    }

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        int[][] a = new int[n][m];
        // za svaki red u matrici
        for (int i = 0; i < a.length; i++) {
            // i za svaku kolonu u aktuelnom redu
            for (int j = 0; j < a[i].length; j++) {
                // da li je element na glavnoj dijagonali?
                if (i == j) {
                    a[i][j] = 1;
                } else {
                    a[i][j] = 0;
                }
                System.out.print(a[i][j] + "  ");
            }
            System.out.println();
        }
        
        //ispis zbira elemenata matrice
        System.out.println("\nZbir elemenata matrice iznosi: " + zbirElem(a));
    }
}
