/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author manojlovic Napisati program koji od korisnika zahteva da unese broj
 * redova i broj kolona. Napraviti matricu nxm sa random elementima koristeći
 * dvodimenzionalni niz. Odrediti zbir i aritmetičku sredinu članova matrice;
 * Prebrojati broj članova matrice koji su veći od aritmetičke sredine; Štampati
 * rezultate na konzoli.
 */
public class Zadatak4 {

    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static int[][] a;
    private static Random rnd = new Random();

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        //unos matrice
        a = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = rnd.nextInt(20);
            }
        }
        //ispis elemenata matrice
        System.out.println("a = ");
        int zbir = 0, count = 0;  //<-- zbir mi treba za racunanje sume elemenata, count mi treba za brojanje elemenata vecih od aritm. sred.
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + " ");
                zbir += a[i][j];
              
            }
            System.out.println();
        }
        System.out.println("Zbir = " + zbir);
        double arit = (double) zbir / (n * m);
        System.out.println("Arit. sred. = " + arit);
        
        //izracunavam koliko imamo elemenata koji su veci od aritemticke sredine
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                 if (a[i][j] > arit) {
                    count++;
                }
            }
        }
        System.out.println("Broj elemenata vecih od aritemticke sredine iznosi: " + count);

    }
}
