/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Scanner;

/**
 *
 * @author manojlovic Učitajte broj vrsta i kolona n i m; Učitajte članove
 * matrice; Pronađite najveći element u matrici; Rezultat pretrage prikazati na
 * konzoli
 */
public class Zadatak2 {

    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static int[][] a;

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        //unos elemenata u matricu
        System.out.println("Unesite elemente matrice:");
        a = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = sc.nextInt();
            }
        }
        //ispis elemenata matrice
        System.out.println("a = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
        //pronalazak i ispis najveceg elementa matrice
        System.out.print("max = ");
        int max = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i][j] > max) {
                    max = a[i][j];
                }
            }
           // System.out.print(max);  //<-- ovo ispisuje najveci elemenat u svakom redu
        }
        System.out.print(max);         //<-- ovo ispisuje njaveci element u celoj matrici
        System.out.println();
    }
}
