/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Scanner;

/**
 *
 * @author manojlovic
 * Izmeniti Primer2 tako da se inicijalizacija matrice vrsi u posebnoj metodi, 
 * kao i izaracunavanje sume i aritmeticke sredine.
 */
public class Primer3 {
    
    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static int[][] a;
    
    //metoda za generisanje matrice
    public static int[][] generateMatrix(int n, int m){
        int[][] a = new int[n][m];
        System.out.println("Unesite elemente matrice:");
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                a[i][j] = sc.nextInt();
            }
        }
        System.out.println("a = ");
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                System.out.print(a[i][j]);
            }
            System.out.println();
        }
        return a;
    }
    
    //metoda za izreacunavanje sume elemenata matrice
    public static int suma(int[][] a){
        int sum=0;
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                sum += a[i][j];
            }
        }
        return sum;
    }
   //metoda za izracunavanje aritmeticke sredine elemenata matrice
    public static double aritMiddle(int suma){
        double rez=0;
        rez = (double)suma/(n*m);
        return rez;
    }
    
    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        a = generateMatrix(n, m);
        int k = suma(a);
        System.out.println("Suma iznosi: " + k);
        System.out.println("Aritmeticka sredina iznosi: " + aritMiddle(k));
    }
}
