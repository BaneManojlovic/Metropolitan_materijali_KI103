/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Scanner;

/**
 *
 * @author manojlovic Učitati i ispisati dvodimenzionalni niz - matricu nxn.
 * Zatim ispisati članove niza koji su na glavnoj dijagonali.
 */
public class Primer4 {

    private static Scanner sc = new Scanner(System.in);
    private static int[][] a;

    public static void main(String[] args) {
        int n=3, m=3;
        a = new int[n][m];
        //ins elemenata u matricu
        System.out.println("Unesite elemente matrice:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = sc.nextInt();
            }
        }
        //ispis elemenata iz matrice
        System.out.println("a = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }

        /**
         * Odvajanje i ispis elemenata sa glavne dijagonale matrice 
         * Elementi za koje vazi da je a[i]==a[j] su elementi na glavnoj dijagonali matrice!!!
         * Elementi iznad glavne dijagonale glavne dijagonale (indeks reda manji od indeksa kolone i<j) 
         * Elementi ispod glavne dijagonale (indeks reda veći od indeksa kolone i>j).
         */
        System.out.print("Elementi glavne dijagonale = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i] == a[j]) {
                    System.out.print(a[i][j] + " ");
                }
            }
        }
        System.out.println();
    }
}
