/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.primeri01;

import java.util.Scanner;

/**
 *
 * @author manojlovic
 * Napisati program koji učitava brojeve n i m sa standardnog ulaza, 
 * zatim učitava n redova i m kolona dvodimenzionalnog niza i ispisuje sumu 
 * i aritmetičku sredinu svih elemenata dvodimenzionalnog niza.
 */
public class Primer2 {
    
    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static int[][] a;
    
    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        a = new int[n][m];
        //unos elemenata u matricu
        System.out.println("Unesite elemente matrice:");
        int suma = 0;
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                a[i][j] = sc.nextInt();
                //sumiranje elemenata matrice
                suma += a[i][j];
            }
        }
        //ispis matrice
        System.out.println("a = ");
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                System.out.print(a[i][j] + " ");
                
            }
            System.out.println();
        }
        //sabiranje elemenata matrice
        System.out.println("Suma iznosi: " + suma);
        //aritmeticka sredina
        System.out.println("Arit. sredina: " + (double)suma/(n*m));
        
    }
}
