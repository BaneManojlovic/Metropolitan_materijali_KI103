/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.domaci;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author manojlovic
 * Napisati program koji od korisnika zahteva da unese veličine dvodimenzionalnog niza n i m.
 * Na osnovu unetih vrednosti kreirati niz random vrednosti. Prebrojati parne i neparne članove
 * niza i kao rezultat štampati veću vrednost od ove dve
 */
public class Zadatak3 {
   
    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static Random rnd = new Random();
    private static int[][] a;
    
    public static void main(String[] args) {
        System.out.println("Uneti n:");
        n = sc.nextInt();
        System.out.println("Uneti m:");
        m = sc.nextInt();
        //unos elemenata matrice
        a = new int[n][m];
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                a[i][j] = rnd.nextInt(20);
            }
        }
        //ispis elemenata matrice
        int countPar=0, countNePar=0;
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                System.out.print(a[i][j] + " ");
                if(a[i][j]%2==0){
                    countPar++;
                }
                 if(a[i][j]%2!=0){
                    countNePar++;
                }
            }
            System.out.println();
        }
        System.out.println("Broj parnih: " + countPar);
        System.out.println("Broj neparnih: " + countNePar);
        if(countPar>countNePar){
            System.out.println("Veci je broj parnih: " + countPar);
        }else if(countPar<countNePar){
            System.out.println("Veci je broj neparnih: " + countNePar);
        }else{
            System.out.println("Jednak je broj parnih i neparnih, tj: " + countPar + " = " + countNePar);
        }
        
    }
}
