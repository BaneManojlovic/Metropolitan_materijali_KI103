/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.domaci;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author manojlovic Napisati program koji od korisnika zahteva da unese
 * veličine dvodimenzionalnog niza n i m. Na osnovu unetih vrednosti kreirati
 * niz random vrednosti. Napisati metodu koja izračunava sumu elemenata na
 * sporednoj dijagonali i dobijeni rezultat odštampati na konzoli.
 */
public class Zadatak1 {

    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static Random rnd = new Random();
    private static int[][] a;

    //metoda koja izracunava sumu svih elemenata na sporednoj dijagonali
    public static int sumElem(int[][] a) {
        int rez = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                try {
                    if (a[i] == a[j]) {
                        //ovako se dobijaju elementi na sporednoj dijagonali
                        rez += a[i][m - i - 1];
                    }
                } catch (Exception ex) {
                    System.out.println("Pozeljno je da n bude jednako m, da bi bila matrica 3x3 ili 4x4!");
                }
            }
        }
        return rez;
    }

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        //unos elemenata u niz
        a = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = rnd.nextInt(20);
            }
        }
        //ispis elemenata
        System.out.println("a = ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }

        int suma = sumElem(a);
        System.out.println("Suma elemenata iznosi: " + suma);

    }
}
