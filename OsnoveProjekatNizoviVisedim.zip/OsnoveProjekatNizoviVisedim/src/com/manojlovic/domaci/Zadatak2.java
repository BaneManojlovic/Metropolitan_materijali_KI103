/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manojlovic.domaci;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author manojlovic Napisati program koji od korisnika zahteva da unese
 * veličine dvodimenzionalnog niza n i m. Generisati random vrednosti za svaki
 * element tog niza. U tako kreiranom nizu potrebno je pronaći maksimalan i
 * minimalan element tog niza i zameniti im mesta.
 */
public class Zadatak2 {

    private static Scanner sc = new Scanner(System.in);
    private static int n, m;
    private static Random rnd = new Random();
    private static int[][] a;

    //metoda koja pronalazi maksimalan element matrice
    public static int maxElem(int[][] a) {
        int max = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i][j] > max) {  //<-- za maksimum je znak za vece
                    max = a[i][j];
                }
            }
        }
        return max;
    }

    //metoda koja pronalazi minimalan element matrice
    public static int minElem(int[][] a) {
        int min = a[0][0];  //<-- da bi nasa minimum, moras ovako da setujes pocetnu vrednost za minimum
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i][j] < min) {  //<-- za minimum je znak za manje
                    min = a[i][j];
                }
            }
        }
        return min;
    }
    
    //zamena elemenata u nizu ali ne radi kao sto bi trebalo!?
    public static int[][] zamenaElem(int[][] a){
   //     int[][] a=null;
        int max = a[0][0];
        int min = a[0][0];
        int temp = 0;
         for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i][j] > min) {  //<-- za maximum je znak za manje
                    min = a[i][j];
                }
                if (a[i][j] < min) {  //<-- za minimum je znak za manje
                    min = a[i][j];
                }
            }
        }
         //zamena meta elementima
        temp = max;
        max = min;
        min = temp;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (a[i][j] > min) {  //<-- za maximum je znak za manje
                    min = a[i][j];
                }
                if (a[i][j] < min) {  //<-- za minimum je znak za manje
                    min = a[i][j];
                }
            }
        }
        return a;
    }

    public static void main(String[] args) {
        System.out.println("Unesite n:");
        n = sc.nextInt();
        System.out.println("Unesite m:");
        m = sc.nextInt();
        //unos elemenata u matricu
        a = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                a[i][j] = rnd.nextInt(20);
            }
        }
        //ispis elemenata iz matrice
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }

        int maximum = maxElem(a);
        System.out.println("Max element matrice je: " + maximum);
        int minimum = minElem(a);
        System.out.println("Min element matrice je: " + minimum);

        //pozicija maksimalnog elementa
        int x, y;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                if (a[i][j] == maximum) {
                    System.out.println("Pozicija maksimalnog elem. je: i = " + i + ", j = " + j);
                    x = i;
                    y = j;
                }
            }
        }
        //pozicija minimalnog elementa
        int t, k;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                if (a[i][j] == minimum) {
                    System.out.println("Pozicija minimalnog elem. je: i = " + i + ", j = " + j);
                    t = i;
                    k = j;
                }
            }
        }
        
        
    }
}
